package terraform

type CallbackUIOutput struct {
	OutputFun func(string)
}
