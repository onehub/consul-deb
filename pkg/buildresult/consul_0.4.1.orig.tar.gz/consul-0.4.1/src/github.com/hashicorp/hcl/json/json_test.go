package json

// This is the directory where our test fixtures are.
const fixtureDir = "./test-fixtures"
